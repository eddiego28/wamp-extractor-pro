from setuptools import setup, find_packages

setup(
    name='WAMPaS',
    version='2.3',
    description='Aplicación de Publicador y Suscriptor WAMP con PyQt5',
    author='Enrique',
    packages=find_packages(),
    install_requires=[
        'PyQt5',
        'autobahn[asyncio]',
        'crossbar',
        'pandas',
        'openpyxl'
    ],
    entry_points={
        'console_scripts': [
            'run_wampas = main:main',
        ],
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
)
