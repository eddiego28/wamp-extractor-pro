# main.py
import sys
import os
import json

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QToolBar, QToolButton, QAction, QMenu,
    QTabWidget, QWidget, QVBoxLayout, QSplashScreen, QMessageBox, QFileDialog,
    QLabel, QDialog, QVBoxLayout as QVBL, QTableWidget, QTableWidgetItem, QHeaderView
)
from PyQt5.QtCore import Qt, QTimer, QSize
from PyQt5.QtGui import QPixmap, QPainter, QColor, QIcon

from publisher.pubGUI import PublisherTab
from subscriber.subGUI import SubscriberTab

# >>> Recorder (nuevo) <<<
from common.recorder import (
    start_recording, stop_recording, is_recording,
    current_logfile, get_counters_snapshot
)

# ----------------------------------------------------------------------
# Utilidades de paths (raíz de proyecto, tanto en script como en .exe)
# ----------------------------------------------------------------------
def get_resource_path(relative_path: str) -> str:
    if getattr(sys, 'frozen', False):
        base_path = os.path.dirname(sys.executable)
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)

def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)

# ----------------------------------------------------------------------
# Splash
# ----------------------------------------------------------------------
def create_splash_screen():
    width, height = 700, 400
    pixmap = QPixmap(width, height)
    pixmap.fill(QColor("#FFFFFF"))
    painter = QPainter(pixmap)
    logo_path = get_resource_path(os.path.join("icons", "logo_wampa.png"))
    logo = QPixmap(logo_path)
    if not logo.isNull():
        logo = logo.scaled(450, 290, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        painter.drawPixmap((width - logo.width()) // 2, 80, logo)
    icon_path = get_resource_path(os.path.join("icons", "open.png"))
    icon = QPixmap(icon_path)
    if not icon.isNull():
        icon = icon.scaled(200, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        painter.drawPixmap((width - icon.width()) // 2, 20, icon)
    painter.end()
    splash = QSplashScreen(pixmap, Qt.WindowStaysOnTopHint)
    splash.showMessage("<h1 style='color: #000000;'>Loading...</h1>",
                       Qt.AlignCenter | Qt.AlignBottom, Qt.white)
    return splash

# ----------------------------------------------------------------------
# Diálogo Breakdown (modal)
# ----------------------------------------------------------------------
class BreakdownDialog(QDialog):
    """Diálogo que muestra el conteo por Realm/Topic y se actualiza en vivo."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Message Breakdown (Subscriber)")
        self.resize(520, 420)
        lay = QVBL(self)
        self.lbl_total = QLabel("Total: 0", self)
        lay.addWidget(self.lbl_total)

        self.table = QTableWidget(0, 3, self)
        self.table.setHorizontalHeaderLabels(["Realm", "Topic", "Count"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.setEditTriggers(self.table.NoEditTriggers)
        lay.addWidget(self.table)

    def update_counts(self, counts: dict, total: int):
        # Rellena tabla entera (rápido y simple)
        self.table.setRowCount(0)
        for realm, topics in sorted(counts.items()):
            for topic, n in sorted(topics.items()):
                r = self.table.rowCount()
                self.table.insertRow(r)
                self.table.setItem(r, 0, QTableWidgetItem(realm))
                self.table.setItem(r, 1, QTableWidgetItem(topic))
                self.table.setItem(r, 2, QTableWidgetItem(str(n)))
        self.lbl_total.setText(f"Total: {total}")

# ----------------------------------------------------------------------
# Main Window
# ----------------------------------------------------------------------
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("WAMPaS Tester v2.3 - Publisher and Subscriber Tool")
        self.resize(1100, 800)

        self.publisherTab = PublisherTab(self)
        self.subscriberTab = SubscriberTab(self)

        self._build_ui()

        # Timer para refrescar contador en vivo
        self._counter_timer = QTimer(self)
        self._counter_timer.setInterval(500)  # ms
        self._counter_timer.timeout.connect(self._refresh_rec_indicator)
        self._counter_timer.start()

    # ---------------- UI ----------------
    def _build_ui(self):
        self._create_toolbar()

        central = QWidget()
        layout = QVBoxLayout(central)
        self.tabs = QTabWidget()
        self.tabs.addTab(self.publisherTab, "Publisher")
        self.tabs.addTab(self.subscriberTab, "Subscriber")
        layout.addWidget(self.tabs)
        self.setCentralWidget(central)

    def _create_toolbar(self):
        self.toolbar = QToolBar("Main Toolbar")
        self.toolbar.setIconSize(QSize(24, 24))
        self.addToolBar(Qt.TopToolBarArea, self.toolbar)

        # --- Load Menu ---
        loadBtn = QToolButton(self)
        loadBtn.setText("Load")
        loadMenu = QMenu(self)
        act_projLoad = QAction("Project", self)
        act_projLoad.triggered.connect(self.loadProject)
        act_pubLoad = QAction("Publisher", self)
        act_pubLoad.triggered.connect(self.publisherTab.loadProject)
        act_subLoad = QAction("Subscriber", self)
        act_subLoad.triggered.connect(self.subscriberTab.loadProject)
        loadMenu.addAction(act_projLoad)
        loadMenu.addAction(act_pubLoad)
        loadMenu.addAction(act_subLoad)
        loadBtn.setMenu(loadMenu)
        loadBtn.setPopupMode(QToolButton.InstantPopup)
        self.toolbar.addWidget(loadBtn)

        # --- Save Menu ---
        saveBtn = QToolButton(self)
        saveBtn.setText("Save")
        saveMenu = QMenu(self)
        act_projSave = QAction("Project", self)
        act_projSave.triggered.connect(self.saveProject)
        act_pubSave = QAction("Publisher", self)
        act_pubSave.triggered.connect(self.publisherTab.saveProject)
        act_subSave = QAction("Subscriber", self)
        act_subSave.triggered.connect(self.subscriberTab.saveProject)
        saveMenu.addAction(act_projSave)
        saveMenu.addAction(act_pubSave)
        saveMenu.addAction(act_subSave)
        saveBtn.setMenu(saveMenu)
        saveBtn.setPopupMode(QToolButton.InstantPopup)
        self.toolbar.addWidget(saveBtn)

        # --- About Menu ---
        aboutBtn = QToolButton(self)
        aboutBtn.setText("About")
        aboutMenu = QMenu(self)
        aboutAct = QAction("About", self)
        aboutAct.triggered.connect(lambda: QMessageBox.information(
            self, "About", "WAMPaS v2.3\nDeveloped by Enrique de Diego\nTADVA3"))
        aboutMenu.addAction(aboutAct)
        aboutBtn.setMenu(aboutMenu)
        aboutBtn.setPopupMode(QToolButton.InstantPopup)
        self.toolbar.addWidget(aboutBtn)

        # --- Help Button ---
        helpAct = QAction("Help", self)
        helpAct.triggered.connect(self.showHelp)
        self.toolbar.addAction(helpAct)

        # Separador
        self.toolbar.addSeparator()

        # --- Recording controls ---
        self.act_startRec = QAction("Start Recording", self)
        self.act_startRec.triggered.connect(self._start_recording_clicked)
        # botón verde
        self.act_startRec.setIcon(self._make_color_icon("#30a46c"))  # verde suave
        self.toolbar.addAction(self.act_startRec)

        self.act_stopRec = QAction("Stop Recording", self)
        self.act_stopRec.triggered.connect(self._stop_recording_clicked)
        # botón rojo
        self.act_stopRec.setIcon(self._make_color_icon("#DC143C"))
        self.toolbar.addAction(self.act_stopRec)



        # Indicador REC en la propia toolbar
        self.lblRec = QLabel("REC ● 0 msgs")
        self.lblRec.setStyleSheet("""
            QLabel {
                padding: 2px 6px;
                border-radius: 6px;
                background: #EEE;
                color: #666;
                font-weight: bold;
            }
        """)
        self.toolbar.addWidget(self.lblRec)

        # Separador
        self.toolbar.addSeparator()
        self.act_breakdown = QAction("Breakdown", self)
        self.act_breakdown.triggered.connect(self._show_breakdown)
        self.toolbar.addAction(self.act_breakdown)
        self._refresh_rec_indicator(force=True)

    def _make_color_icon(self, hex_color: str) -> QIcon:
        pm = QPixmap(24, 24)
        pm.fill(Qt.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setBrush(QColor(hex_color))
        p.setPen(Qt.NoPen)
        p.drawRoundedRect(2, 2, 20, 20, 6, 6)
        p.end()
        return QIcon(pm)

    # ------------- Toolbar handlers -------------
    def _start_recording_clicked(self):
        # Crear carpeta logs en raíz del proyecto y archivo con timestamp
        try:
            logs_dir = get_resource_path("logs")
            ensure_dir(logs_dir)
            # nombre por defecto: WAMPaS_YYYYmmdd_HHMMSS.json (lo hace start_recording)
            path = start_recording(base_dir=get_resource_path(""))
            QMessageBox.information(self, "Recording",
                                    f"Recording started.\nFile:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Recording Error", str(e))
        self._refresh_rec_indicator(force=True)

    def _stop_recording_clicked(self):
        try:
            path = stop_recording()
            if path:
                QMessageBox.information(self, "Recording",
                                        f"Recording stopped.\nFile saved:\n{path}")
            else:
                QMessageBox.information(self, "Recording", "No active recording.")
        except Exception as e:
            QMessageBox.critical(self, "Recording Error", str(e))
        self._refresh_rec_indicator(force=True)

    def _show_breakdown(self):
        total, by_rt = get_counters_snapshot()
        dlg = BreakdownDialog(total, by_rt, self)
        dlg.exec_()

    def _refresh_rec_indicator(self, force: bool = False):
        rec = is_recording()
        total, _ = get_counters_snapshot()

        if rec:
            self.lblRec.setText(f"REC ● {total} msgs")
            self.lblRec.setStyleSheet("""
                QLabel {
                    padding: 2px 6px;
                    border-radius: 6px;
                    background: #ffe8e6;
                    color: #b42318;   /* rojo */
                    font-weight: bold;
                }
            """)
        else:
            self.lblRec.setText("REC ● 0 msgs")
            self.lblRec.setStyleSheet("""
                QLabel {
                    padding: 2px 6px;
                    border-radius: 6px;
                    background: #EEE;
                    color: #666;
                    font-weight: bold;
                }
            """)

        # Habilitar/deshabilitar acciones coherentes
        self.act_startRec.setEnabled(not rec)
        self.act_stopRec.setEnabled(rec)
        self.act_breakdown.setEnabled(True)  # permitir ver breakdown incluso parado

    # ------------- Project Save/Load -------------
    def showHelp(self):
        QMessageBox.information(
            self, "Help",
            "Use the Load/Save menus to manage Publisher, Subscriber or full Project configurations.\n"
            "Load → Project opens 'projects',\n"
            "Load → Publisher opens 'projects/publisher',\n"
            "Load → Subscriber opens 'projects/subscriber'."
        )

    def saveProject(self):
        base_dir = get_resource_path('projects')
        ensure_dir(base_dir)
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Save Project", base_dir, "JSON Files (*.json)"
        )
        if not filepath:
            return
        project = {
            "publisher": self.publisherTab.getProjectConfig(),
            "subscriber": self.subscriberTab.getProjectConfig()
        }
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(project, f, indent=2, ensure_ascii=False)
            QMessageBox.information(self, "Project", "Project saved successfully.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not save project:\n{e}")

    def loadProject(self):
        base_dir = get_resource_path('projects')
        ensure_dir(base_dir)
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Load Project", base_dir, "JSON Files (*.json)"
        )
        if not filepath:
            return
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                project = json.load(f)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not load project:\n{e}")
            return
        # Loading both tabs
        self.publisherTab.loadProjectFromConfig(project.get('publisher', {}))
        self.subscriberTab.loadProjectFromConfig(project.get('subscriber', {}))
        QMessageBox.information(self, "Project", "Project loaded successfully.")

# ----------------------------------------------------------------------
# Arranque
# ----------------------------------------------------------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon(get_resource_path("icons/logo_wampa.png")))
    splash = create_splash_screen()
    if splash:
        splash.show()
    main_window = MainWindow()
    QTimer.singleShot(1000, splash.close)
    QTimer.singleShot(1000, main_window.show)
    sys.exit(app.exec_())