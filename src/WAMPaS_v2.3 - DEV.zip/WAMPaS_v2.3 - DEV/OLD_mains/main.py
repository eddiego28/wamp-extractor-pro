# main.py
import sys
import os
import json

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QToolBar, QToolButton, QAction, QMenu,
    QTabWidget, QWidget, QVBoxLayout, QSplashScreen, QMessageBox, QFileDialog,
    QLabel, QDialog, QTableWidget, QTableWidgetItem, QHeaderView, QPushButton, QHBoxLayout
)
from PyQt5.QtCore import Qt, QTimer, QSize
from PyQt5.QtGui import QPixmap, QPainter, QColor, QIcon

from publisher.pubGUI import PublisherTab
from subscriber.subGUI import SubscriberTab

# <-- Clave: usamos el recorder como fuente única de verdad
from common import recorder


def get_resource_path(relative_path):
    # Base del proyecto (junto al exe si está congelado)
    if getattr(sys, 'frozen', False):
        base_path = os.path.dirname(sys.executable)
    else:
        base_path = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, relative_path)


def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)


def create_splash_screen():
    width, height = 700, 400
    pixmap = QPixmap(width, height)
    pixmap.fill(QColor("#FFFFFF"))
    painter = QPainter(pixmap)

    logo_path = get_resource_path(os.path.join("icons", "logo_wampa.png"))
    logo = QPixmap(logo_path)
    if not logo.isNull():
        logo = logo.scaled(450, 290, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        painter.drawPixmap((width - logo.width()) // 2, 80, logo)

    icon_path = get_resource_path(os.path.join("icons", "open.png"))
    icon = QPixmap(icon_path)
    if not icon.isNull():
        icon = icon.scaled(200, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        painter.drawPixmap((width - icon.width()) // 2, 20, icon)

    painter.end()
    splash = QSplashScreen(pixmap, Qt.WindowStaysOnTopHint)
    splash.showMessage("<h1 style='color: #000000;'>Loading...</h1>",
                       Qt.AlignCenter | Qt.AlignBottom, Qt.white)
    return splash


# -----------------------
# Diálogo de Breakdown RT
# -----------------------
class BreakdownDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Message Breakdown (Realm / Topic)")
        self.resize(500, 400)

        layout = QVBoxLayout(self)

        # Tabla: Realm | Topic | Count
        self.table = QTableWidget(0, 3, self)
        self.table.setHorizontalHeaderLabels(["Realm", "Topic", "Count"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        layout.addWidget(self.table)

        # Barra inferior con total y cerrar
        bottom = QHBoxLayout()
        self.lblTotal = QLabel("Total: 0")
        bottom.addWidget(self.lblTotal)
        bottom.addStretch(1)
        btnClose = QPushButton("Close")
        btnClose.clicked.connect(self.close)
        bottom.addWidget(btnClose)
        layout.addLayout(bottom)

        # Timer de refresco en vivo
        self._timer = QTimer(self)
        self._timer.setInterval(500)  # 0.5s
        self._timer.timeout.connect(self.refresh)
        self._timer.start()

        # Refresco inicial
        self.refresh()

    def refresh(self):
        total, by_rt = recorder.get_counters_snapshot()
        # Rellenar tabla
        self.table.setRowCount(0)
        for realm, topic_map in sorted(by_rt.items()):
            for topic, count in sorted(topic_map.items()):
                r = self.table.rowCount()
                self.table.insertRow(r)
                self.table.setItem(r, 0, QTableWidgetItem(str(realm)))
                self.table.setItem(r, 1, QTableWidgetItem(str(topic)))
                self.table.setItem(r, 2, QTableWidgetItem(str(count)))
        self.lblTotal.setText(f"Total: {total}")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("WAMPaS Tester v2.3 - Publisher and Subscriber Tool")
        self.resize(1100, 800)

        self.publisherTab = PublisherTab(self)
        self.subscriberTab = SubscriberTab(self)

        # Conectar (si existe) señal para provocar refresco inmediato del contador
        if hasattr(self.subscriberTab, "messageCounted"):
            try:
                self.subscriberTab.messageCounted.connect(self._on_count_from_sub)
            except Exception:
                pass

        self._breakdown_dialog = None

        self.initUI()

        # Status bar con contador en tiempo real
        self.statusLabel = QLabel("Ready")
        self.statusBar().addPermanentWidget(self.statusLabel)

        # Timer para refrescar en cualquier caso (cada 0.5s)
        self._status_timer = QTimer(self)
        self._status_timer.setInterval(500)
        self._status_timer.timeout.connect(self._refresh_status_total)
        self._status_timer.start()

        # Refresco inicial
        self._refresh_status_total()

    def initUI(self):
        self.createToolBar()

        centralWidget = QWidget()
        mainLayout = QVBoxLayout(centralWidget)

        self.tabs = QTabWidget()
        self.tabs.addTab(self.publisherTab, "Publisher")
        self.tabs.addTab(self.subscriberTab, "Subscriber")

        mainLayout.addWidget(self.tabs)
        self.setCentralWidget(centralWidget)

    def createToolBar(self):
        self.toolbar = QToolBar("Main Toolbar")
        self.toolbar.setIconSize(QSize(24, 24))
        self.addToolBar(Qt.TopToolBarArea, self.toolbar)

        # --- Load Menu ---
        loadBtn = QToolButton(self)
        loadBtn.setText("Load")
        loadMenu = QMenu(self)
        projLoad = QAction("Project", self)
        projLoad.triggered.connect(self.loadProject)
        pubLoad = QAction("Publisher", self)
        pubLoad.triggered.connect(self.publisherTab.loadProject)
        subLoad = QAction("Subscriber", self)
        subLoad.triggered.connect(self.subscriberTab.loadProject)
        loadMenu.addAction(projLoad)
        loadMenu.addAction(pubLoad)
        loadMenu.addAction(subLoad)
        loadBtn.setMenu(loadMenu)
        loadBtn.setPopupMode(QToolButton.InstantPopup)
        self.toolbar.addWidget(loadBtn)

        # --- Save Menu ---
        saveBtn = QToolButton(self)
        saveBtn.setText("Save")
        saveMenu = QMenu(self)
        projSave = QAction("Project", self)
        projSave.triggered.connect(self.saveProject)
        pubSave = QAction("Publisher", self)
        pubSave.triggered.connect(self.publisherTab.saveProject)
        subSave = QAction("Subscriber", self)
        subSave.triggered.connect(self.subscriberTab.saveProject)
        saveMenu.addAction(projSave)
        saveMenu.addAction(pubSave)
        saveMenu.addAction(subSave)
        saveBtn.setMenu(saveMenu)
        saveBtn.setPopupMode(QToolButton.InstantPopup)
        self.toolbar.addWidget(saveBtn)

        # --- Recording controls ---
        self.actStartRec = QAction("Rec", self)
        self.actStartRec.setToolTip("Start recording")
        self.actStartRec.setIconText("● Record")
        self.actStartRec.triggered.connect(self._start_recording)
        # Botón con estilo verde
        startBtn = QToolButton(self)
        startBtn.setDefaultAction(self.actStartRec)
        startBtn.setStyleSheet("QToolButton { background-color: #27ae60; color: white; font-weight: bold; padding: 4px 8px; }")
        self.toolbar.addWidget(startBtn)

        self.actStopRec = QAction("Stop", self)
        self.actStopRec.setToolTip("Stop recording")
        self.actStopRec.setIconText("■ Stop")
        self.actStopRec.triggered.connect(self._stop_recording)
        # Botón con estilo naranja
        stopBtn = QToolButton(self)
        stopBtn.setDefaultAction(self.actStopRec)
        stopBtn.setStyleSheet("""
            QLabel {
                padding: 2px 6px;
                border-radius: 6px;
                background: #EEE;
                color: #666;
                font-weight: bold;
            }
        """)
        self.toolbar.addWidget(stopBtn)



        # --- About Menu ---
        aboutBtn = QToolButton(self)
        aboutBtn.setText("About")
        aboutMenu = QMenu(self)
        aboutAct = QAction("About", self)
        aboutAct.triggered.connect(lambda: QMessageBox.information(
            self, "About", "WAMPaS v2.3\nDeveloped by Enrique de Diego\nTADVA3"))
        aboutMenu.addAction(aboutAct)
        aboutBtn.setMenu(aboutMenu)
        aboutBtn.setPopupMode(QToolButton.InstantPopup)
        self.toolbar.addWidget(aboutBtn)

        # --- Help Button ---
        helpAct = QAction("Help", self)
        helpAct.triggered.connect(self.showHelp)
        self.toolbar.addAction(helpAct)

        # --- Breakdown (tiempo real) ---
        self.actBreakdown = QAction("Breakdown", self)
        self.actBreakdown.setToolTip("Realm/Topic count in real time")
        self.actBreakdown.triggered.connect(self._open_breakdown)
        self.toolbar.addAction(self.actBreakdown)

    def showHelp(self):
        QMessageBox.information(
            self, "Help",
            "Use Load/Save para gestionar configuraciones Publisher/Subscriber o proyectos completos.\n"
            "Los botones 'Grabar' y 'Parar' controlan la grabación del log JSON.\n"
            "El botón 'Breakdown' muestra los contadores en tiempo real por Realm/Topic."
        )

    # ---------------- Recording handlers ----------------
    def _start_recording(self):
        if recorder.is_recording():
            # Ya grabando: muestra la ruta por si acaso
            path = recorder.current_logfile() or "(no file)"
            QMessageBox.information(self, "Recording", f"Ya está grabando en:\n{path}")
            return

        # Crear logs/ bajo la raíz del proyecto (get_resource_path)
        base_dir = get_resource_path("")
        try:
            path = recorder.start_recording(base_dir=base_dir, filename=None)
            QMessageBox.information(self, "Recording", f"Grabación iniciada:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Recording", f"No se pudo iniciar la grabación:\n{e}")
        self._refresh_status_total()

    def _stop_recording(self):
        if not recorder.is_recording():
            QMessageBox.information(self, "Recording", "No hay grabación activa.")
            return
        try:
            path = recorder.stop_recording()
            QMessageBox.information(self, "Recording", f"Grabación detenida.\nFichero generado:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Recording", f"No se pudo detener la grabación:\n{e}")
        self._refresh_status_total()

    def _open_breakdown(self):
        # Ventana no modal y re-usable
        if self._breakdown_dialog and self._breakdown_dialog.isVisible():
            self._breakdown_dialog.raise_()
            self._breakdown_dialog.activateWindow()
            return
        self._breakdown_dialog = BreakdownDialog(self)
        self._breakdown_dialog.setWindowModality(Qt.NonModal)
        self._breakdown_dialog.show()

    # ------------ Status/contador ------------
    def _on_count_from_sub(self, realm: str, topic: str):
        # No sumamos nada aquí: recorder ya incrementó.
        self._refresh_status_total()

    def _refresh_status_total(self):
        total, _ = recorder.get_counters_snapshot()
        if recorder.is_recording():
            self.statusLabel.setText(f"● Recording…   messages: {total}")
        else:
            self.statusLabel.setText(f"Ready — messages (last session): {total}")

    # ---------------- Save/Load Project ----------------
    def saveProject(self):
        base_dir = get_resource_path('projects')
        ensure_dir(base_dir)
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Save Project", base_dir, "JSON Files (*.json)"
        )
        if not filepath:
            return
        project = {
            "publisher": self.publisherTab.getProjectConfig(),
            "subscriber": self.subscriberTab.getProjectConfig()
        }
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(project, f, indent=2, ensure_ascii=False)
            QMessageBox.information(self, "Project", "Project saved successfully.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not save project:\n{e}")

    def loadProject(self):
        base_dir = get_resource_path('projects')
        ensure_dir(base_dir)
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Load Project", base_dir, "JSON Files (*.json)"
        )
        if not filepath:
            return
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                project = json.load(f)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not load project:\n{e}")
            return
        # Loading both tabs
        self.publisherTab.loadProjectFromConfig(project.get('publisher', {}))
        self.subscriberTab.loadProjectFromConfig(project.get('subscriber', {}))
        QMessageBox.information(self, "Project", "Project loaded successfully.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon(get_resource_path("icons/logo_wampa.png")))
    splash = create_splash_screen()
    if splash:
        splash.show()
    main_window = MainWindow()
    QTimer.singleShot(800, splash.close)
    QTimer.singleShot(800, main_window.show)
    sys.exit(app.exec_())