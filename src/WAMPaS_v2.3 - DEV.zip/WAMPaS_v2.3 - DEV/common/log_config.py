import os
import json
import datetime
import logging
import sys
import copy

#Function in charge of create de directory in case it does not exist.
def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path, exist_ok=True)

# Determine the main path
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Set a directory for the logs
LOG_DIR = os.path.join(BASE_DIR, "logs")
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

# Create a name for the file
LOG_FILENAME = os.path.join(LOG_DIR, f"log_{datetime.datetime.now().strftime('%Y-%m-%d_%H%M%S')}.txt")

#Template file
TEMPLATE_FILE = os.path.join(BASE_DIR, "header_template.json")

# Config logger
logger = logging.getLogger("FileLogger")
logger.setLevel(logging.INFO)

# Create a FileHandler to write in the log file, using UTF-8
file_handler = logging.FileHandler(LOG_FILENAME, encoding="utf-8")
formatter = logging.Formatter('%(asctime)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)