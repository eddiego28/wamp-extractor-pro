# common/recorder.py
import os
import sys
import json
import tempfile
import threading
from datetime import datetime
from collections import defaultdict
from typing import Any, Dict, Optional, Tuple

# =========================
# Estado interno del recorder
# =========================
_lock = threading.RLock()
_recording_enabled: bool = False
_logfile_path: Optional[str] = None

# Contadores
_total_count: int = 0
_by_realm_topic: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))

# =========================
# Utilidades de ruta base
# =========================
def _get_base_dir() -> str:
    """
    Raíz del proyecto:
      - Si está 'frozen' (exe): directorio junto al ejecutable.
      - Si no, el directorio raíz del proyecto (un nivel por encima de 'common').
    """
    if getattr(sys, "frozen", False):
        base = os.path.dirname(sys.executable)
    else:
        # common/recorder.py -> sube 1 nivel para llegar a raíz del proyecto
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return base

def _ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)

def current_logfile() -> Optional[str]:
    """ Devuelve la ruta del log activo (o None si no hay grabación). """
    with _lock:
        return _logfile_path

def is_recording() -> bool:
    """ ¿Está activa la grabación? """
    with _lock:
        return _recording_enabled

# =========================
# Inicialización JSON (plantilla)
# =========================
def _initial_json() -> Dict[str, Any]:
    return {
        "comments": "WAMP messages register",
        "source": {"jsonSrc": "", "toolName": "WAMPaS", "toolVer": "1.2"},
        "defTimeFmt": "%Y-%m-%d %H:%M:%S",
        "msg_list": []
    }

def _safe_load_json(path: str) -> Dict[str, Any]:
    """
    Lee JSON del disco. Si no existe o está corrupto, devuelve la plantilla.
    """
    try:
        if not os.path.exists(path):
            return _initial_json()
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        # Archivo corrupto o concurrente → empezamos de nuevo (no rompemos el flujo)
        return _initial_json()

def _safe_write_json(path: str, data: Dict[str, Any]) -> None:
    """
    Escritura atómica: volcado a fichero temporal + os.replace.
    Evita JSONs truncados y errores tipo “expected ',' delimiter”.
    """
    directory = os.path.dirname(path)
    _ensure_dir(directory)
    fd, tmp_name = tempfile.mkstemp(prefix=".wampas_", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as tmp:
            json.dump(data, tmp, indent=2, ensure_ascii=False)
            tmp.flush()
            os.fsync(tmp.fileno())
        os.replace(tmp_name, path)
    finally:
        try:
            if os.path.exists(tmp_name):
                os.remove(tmp_name)
        except Exception:
            pass

# =========================
# API pública
# =========================
def start_recording(base_dir: Optional[str] = None, filename: Optional[str] = None) -> str:
    """
    Empieza una sesión de grabación. Crea el fichero JSON con la plantilla.
    - base_dir: carpeta base donde crear 'logs/'. Si None → raíz del proyecto.
    - filename: nombre del fichero. Si None → 'WAMPaS_YYYYmmdd_HHMMSS.json'

    Devuelve la ruta del fichero de log creado.
    """
    global _recording_enabled, _logfile_path, _total_count, _by_realm_topic

    with _lock:
        if _recording_enabled:
            # Ya hay una grabación activa → devuelve el actual
            return _logfile_path or ""

        root = base_dir or _get_base_dir()
        logs_dir = os.path.join(root, "logs")
        _ensure_dir(logs_dir)

        if not filename:
            filename = datetime.now().strftime("WAMPaS_%Y%m%d_%H%M%S.json")

        _logfile_path = os.path.join(logs_dir, filename)

        # Inicializa el JSON en disco
        data = _initial_json()
        _safe_write_json(_logfile_path, data)

        # Reset contadores
        _total_count = 0
        _by_realm_topic = defaultdict(lambda: defaultdict(int))

        _recording_enabled = True
        return _logfile_path

def stop_recording() -> Optional[str]:
    """
    Termina la sesión de grabación. No modifica el fichero, solo desactiva.
    Devuelve la ruta del fichero que quedó generado (o None si no había).
    """
    global _recording_enabled, _logfile_path
    with _lock:
        path = _logfile_path
        _recording_enabled = False
        _logfile_path = None
        return path

def get_counters_snapshot() -> Tuple[int, Dict[str, Dict[str, int]]]:
    """
    Devuelve (total, por_realm_topic) con una copia segura de los contadores.
    """
    with _lock:
        total = _total_count
        # deep-copy simple
        by_rt = {r: dict(tmap) for r, tmap in _by_realm_topic.items()}
        return total, by_rt

def reset_counters() -> None:
    """ Pone a cero los contadores (sin afectar a la grabación ni al fichero). """
    global _total_count, _by_realm_topic
    with _lock:
        _total_count = 0
        _by_realm_topic = defaultdict(lambda: defaultdict(int))

def log_to_file(timestamp: str, realm: str, topic: str, router_url: str, payload: Any) -> None:
    """
    Añade una entrada a msg_list del fichero activo (si hay grabación).
    - timestamp: "YYYY-mm-dd HH:MM:SS"
    - realm, topic
    - router_url → se escribe en 'srcIPAddr'
    - payload: dict/list → tal cual; escalar/str → {'raw': str(payload)}

    Respeta tu formato:
      'timestamp': {'data': <fecha>, 'format': <hora>}
      'srcIPAddr', 'dstIPAddr', 'tProtocol', 'srcPort', 'dstPort'
    """
    with _lock:
        if not _recording_enabled or not _logfile_path:
            return  # Si no está grabando, no hace nada

        # --- Contadores ---
        global _total_count, _by_realm_topic
        _total_count += 1
        _by_realm_topic[realm][topic] += 1

        # --- Preparación de entrada ---
        try:
            date_str, time_str = timestamp.split(" ", 1)
        except ValueError:
            date_str, time_str = timestamp, ""

        # Carga segura del JSON actual
        data = _safe_load_json(_logfile_path)

        entries = data.get("msg_list")
        if not isinstance(entries, list):
            entries = []
            data["msg_list"] = entries

        if isinstance(payload, (dict, list)):
            payload_obj = payload
        else:
            payload_obj = {"raw": str(payload)}

        entry = {
            "timestamp": {"data": date_str, "format": time_str},
            "realm": realm,
            "topic": topic,
            "srcIPAddr": router_url or "",
            "dstIPAddr": "",
            "tProtocol": "",
            "srcPort": "",
            "dstPort": "",
            "payload": payload_obj
        }

        entries.append(entry)

        # Escritura atómica
        _safe_write_json(_logfile_path, data)