import os
import json
import logging
import sys
from datetime import datetime

# -------------------------------------------------------------------------
# Configuración de carpeta y fichero de logs
# -------------------------------------------------------------------------
# Determine the main path
if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Directorio para logs
LOG_DIR = os.path.join(BASE_DIR, 'logs')
# Crear directorio si no existe
os.makedirs(LOG_DIR, exist_ok=True)
# Nombre de fichero con fecha y hora actuales
LOGFILE = os.path.join(
    LOG_DIR,
    datetime.now().strftime('%Y%m%d_%H%M%S') + '.json'
)

# Inicializar fichero con plantilla si no existe
if not os.path.exists(LOGFILE):
    initial = {
        "comments": "WAMP messages register",
        "source": {"jsonSrc": "", "toolName": "WAMPaS", "toolVer": "1.2"},
        "defTimeFmt": "%Y-%m-%d %H:%M:%S",
        "msg_list": []
    }
    try:
        with open(LOGFILE, 'w', encoding='utf-8') as f:
            json.dump(initial, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logging.error(f"Impossible to create log: {e}")

# -------------------------------------------------------------------------
# Función para registrar mensajes en el JSON de logs
# -------------------------------------------------------------------------
def log_to_file(timestamp, realm, topic, router_url, payload):
    """
    Add an entry to the LOGFILE in "msg_list" with fields:
      - timestamp: { date, time }
      - realm, topic
      - ip_source, ip_dest
      - payload (dict o raw)
    """
    # separar fecha y hora
    try:
        date_str, time_str = timestamp.split(' ', 1)
    except ValueError:
        date_str, time_str = timestamp, ''

    # cargar datos existentes
    try:
        with open(LOGFILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        logging.error(f"Error reading {LOGFILE}: {e}")
        return

    # asegurar lista
    entries = data.get('msg_list')
    if not isinstance(entries, list):
        entries = []
        data['msg_list'] = entries

    # construir entrada
    entry = {
        'timestamp': {'data': date_str, 'format': time_str},
        'realm': realm,
        'topic': topic,
        'srcIPAddr': router_url or '',
        'dstIPAddr': '',
        'tProtocol': '',
        'srcPort':  '',
        'dstPort':  '',
        'payload': payload if isinstance(payload, dict) else {'raw': str(payload)}
    }
    entries.append(entry)

    # guardar de vuelta
    try:
        with open(LOGFILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logging.error(f"Writing error {LOGFILE}: {e}")