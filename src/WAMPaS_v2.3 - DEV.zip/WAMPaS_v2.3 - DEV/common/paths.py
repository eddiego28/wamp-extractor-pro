import os
import sys
import shutil
import json

def get_project_root():
    """Raíz del proyecto: carpeta del exe en empaquetado o del archivo en dev."""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(sys.argv[0]))

def get_embedded_path(rel_path: str) -> str:
    """Ruta a un recurso embebido (--add-data)."""
    base = getattr(sys, '_MEIPASS', None)
    if base:
        return os.path.join(base, rel_path)
    return os.path.join(get_project_root(), rel_path)

def ensure_external_config(rel_output: str, rel_embedded_default: str) -> str:
    """
    Garantiza que existe un fichero de config escribible externo.
    Si no existe, copia el default embebido.
    """
    out_path = os.path.join(get_project_root(), rel_output)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    if not os.path.exists(out_path):
        default_path = get_embedded_path(rel_embedded_default)
        if os.path.exists(default_path):
            shutil.copy2(default_path, out_path)
        else:
            # Si no hay default embebido, crea uno mínimo
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump({"realms": []}, f, indent=2, ensure_ascii=False)
    return out_path

def ensure_project_subdir(subdir: str) -> str:
    """Crea y devuelve un subdirectorio dentro de la raíz del proyecto."""
    path = os.path.join(get_project_root(), subdir)
    os.makedirs(path, exist_ok=True)
    return path