# common/excel_exporter.py
import json
from typing import Any, Dict, List, Tuple

import pandas as pd

try:
    from openpyxl import load_workbook
    from openpyxl.styles import PatternFill
except Exception:
    load_workbook = None
    PatternFill = None

def flatten_json(value: Any, parent_key: str = "", sep: str = ".") -> Dict[str, Any]:
    flat_items: List[Tuple[str, Any]] = []
    if isinstance(value, dict):
        for k, v in value.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            flat_items.extend(flatten_json(v, new_key, sep=sep).items())
    elif isinstance(value, list):
        for i, item in enumerate(value):
            new_key = f"{parent_key}[{i}]" if parent_key else f"[{i}]"
            flat_items.extend(flatten_json(item, new_key, sep=sep).items())
    else:
        flat_items.append((parent_key if parent_key else "value", value))
    return dict(flat_items)

def _export_qtable_to_excel(qtable, messages: List[Any], filepath: str, default_source: str):
    rows: List[Dict[str, Any]] = []
    ordered_payload_fields: List[str] = []

    nrows = qtable.rowCount()
    ncols = qtable.columnCount()

    for r in range(nrows):
        time_val  = qtable.item(r, 0).text() if ncols > 0 and qtable.item(r, 0) else ""
        realm_val = qtable.item(r, 1).text() if ncols > 1 and qtable.item(r, 1) else ""
        topic_val = qtable.item(r, 2).text() if ncols > 2 and qtable.item(r, 2) else ""
        # Si no existe la columna Source en la tabla, usa el valor por defecto
        source_val = qtable.item(r, 3).text() if ncols > 3 and qtable.item(r, 3) else default_source

        base = {"Time": time_val, "Realm": realm_val, "Topic": topic_val, "Source": source_val}

        payload = messages[r] if r < len(messages) else None
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except Exception:
                pass

        if isinstance(payload, (dict, list)):
            flat = flatten_json(payload)
        elif payload is not None:
            flat = {"value": payload}
        else:
            flat = {}

        for k in flat.keys():
            if k not in ordered_payload_fields:
                ordered_payload_fields.append(k)

        base.update(flat)
        rows.append(base)

    columns = ["Time", "Realm", "Topic", "Source"] + ordered_payload_fields
    df = pd.DataFrame(rows, columns=columns)
    df.to_excel(filepath, index=False)

    if load_workbook is None or PatternFill is None:
        return

    try:
        wb = load_workbook(filepath)
        ws = wb.active
        first_payload_col = 5  # E
        orange = PatternFill(start_color="FFF4CC", end_color="FFF4CC", fill_type="solid")

        for col in range(first_payload_col, first_payload_col + len(ordered_payload_fields)):
            prev_val = None
            for row in range(2, ws.max_row + 1):
                cell = ws.cell(row=row, column=col)
                val = cell.value
                if row == 2:
                    prev_val = val
                    continue
                if val != prev_val and (val is not None or prev_val is not None):
                    cell.fill = orange
                prev_val = val

        wb.save(filepath)
    except Exception:
        pass

def export_subscriber_table_to_excel(qtable, messages: List[Any], filepath: str):
    _export_qtable_to_excel(qtable, messages, filepath, default_source="SUBSCRIBER")

def export_publisher_table_to_excel(qtable, messages: List[Any], filepath: str):
    _export_qtable_to_excel(qtable, messages, filepath, default_source="PUBLISHER")