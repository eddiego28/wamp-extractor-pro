# subscriber/subGUI.py
import sys
import os
import json
import datetime
import time
import asyncio
import threading
import logging
import re
from PyQt5.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox, QLineEdit, QFileDialog,
    QCheckBox, QTextEdit, QTabWidget, QDialog, QTreeWidget, QTreeWidgetItem,
    QInputDialog, QProgressDialog, QApplication
)
from PyQt5.QtCore import Qt, pyqtSlot, pyqtSignal, QTimer
from PyQt5.QtGui import QColor

from autobahn.asyncio.component import Component
from common.paths import ensure_external_config, ensure_project_subdir
from common.recorder import log_to_file

# ---- logging ----
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
if not logger.handlers:
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter("%(asctime)s %(levelname)s: %(message)s"))
    logger.addHandler(ch)

# # ---- log_to_file opcional ----
# try:
#     from common.utils import log_to_file
# except Exception:
#     def log_to_file(*args, **kwargs):
#         pass

# ================== CORE RUNTIME (hilos / componente) ==================

_active_comps = {}  # realm -> {comp, loop, thread, subs, task, cfg, watchdog}
_ACTIVE_LOCK = threading.RLock()


def make_component(realm, url, transport, serializers, topics, on_message_callback):
    """Crea el Component y conecta todos los eventos que pintan filas (incluyendo errores)."""
    # Transport config
    if transport == "websocket":
        full_url = url if (url or "").startswith("ws://") else f"ws://{url}"
        tx = {"type": "websocket", "url": full_url, "serializers": (serializers or ["json"])}
    else:
        m = re.match(r"^([^:/\s]+):(\d+)$", url or "")
        if not m:
            raise ValueError(f"RawSocket Invalid URL: {url}")
        host, port = m.group(1), int(m.group(2))
        tx = {
            "type": "rawsocket",
            "endpoint": {"type": "tcp", "host": host, "port": port},
            "serializer": (serializers or ["json"])[0]
        }

    comp = Component(transports=[tx], realm=realm)
    comp._subscriptions = []
    comp._session = None
    comp._connected_flag = False  # watchdog usa esto

    # Topics sin duplicados preservando orden
    seen = set()
    topics_unique = [t for t in (topics or []) if not (t in seen or seen.add(t))]

    @comp.on_join
    async def joined(session, details):
        comp._session = session
        comp._connected_flag = True
        ts0 = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        for t in topics_unique:
            try:
                def make_on_message(tcopy):
                    async def on_message(*args, **kwargs):
                        # payload robusto
                        if args and isinstance(args[0], dict):
                            payload = dict(args[0])
                        elif kwargs:
                            payload = dict(kwargs)
                        elif args:
                            payload = args[0]
                        else:
                            payload = {}

                        # marca de origen
                        source = "remote"
                        if isinstance(payload, dict) and payload.get("__src") == "me":
                            source = "me"
                            payload.pop("__src", None)

                        on_message_callback(
                            realm, tcopy,
                            datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            payload, False, source
                        )

                    return on_message

                sub = await session.subscribe(make_on_message(t), t)
                comp._subscriptions.append(sub)
                on_message_callback(realm, t, ts0, "Subscribed OK", False, "system")

            except Exception as e:
                on_message_callback(realm, t, ts0, f"Error subscribing: {e}", True, "system")

    # Estos eventos pueden no disparar en todos los routers, pero si llegan pintan ROJO
    @comp.on_connectfailure
    def connectfailure(details):
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        on_message_callback(realm, "", ts, f"Connect failure: {details}", True, "system")

    @comp.on_disconnect
    def disconnected(details):
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        on_message_callback(realm, "", ts, f"Disconnected: {details}", True, "system")

    @comp.on_leave
    def left(session, details):
        ts1 = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        on_message_callback(realm, "", ts1, f"Left: {details}", True, "system")

    return comp


def start_subscriber(url, realm, topics, on_message_callback, transport="websocket", serializers=None):
    """Arranca un subscriber en su hilo/event loop, con watchdog de conexión y errores visibles."""
    serializers = serializers or ["json"]
    topics = topics or []
    topics_label = ",".join(topics)

    # Normaliza/valida URL. Si es inválida, también pintamos ROJO.
    url = (url or "").strip()
    if transport == "websocket" and not url.startswith("ws://"):
        url = "ws://" + url

    if transport == "websocket":
        if not re.match(r"^ws://[^:/\s]+:\d+$", url):
            ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            on_message_callback(realm, topics_label, ts, f"Invalid URL: {url}", True, "system")
            return
    else:
        if not re.match(r"^[^:/\s]+:\d+$", url):
            ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            on_message_callback(realm, topics_label, ts, f"Invalid RawSocket URL: {url}", True, "system")
            return
        if len(serializers) > 1:
            serializers = [serializers[0]]

    try:
        comp = make_component(realm, url, transport, serializers, topics, on_message_callback)
    except Exception as e:
        # Error construyendo el componente -> pinta en rojo y sal
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        on_message_callback(realm, topics_label, ts, f"Component build error: {e}", True, "system")
        return

    loop_holder = {}

    def _thread_main():
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop_holder["loop"] = loop

            # arranca sin bloquear
            task = comp.start(loop=loop)

            with _ACTIVE_LOCK:
                if realm in _active_comps:
                    _active_comps[realm]["task"] = task

            loop.run_forever()
        except Exception as e:
            # Si el hilo peta al arrancar, avisa con fila roja
            ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            on_message_callback(realm, topics_label, ts, f"Thread start error: {e}", True, "system")
        finally:
            try:
                if "loop" in loop_holder and loop_holder["loop"].is_running():
                    loop_holder["loop"].stop()
            except Exception:
                pass
            try:
                if "loop" in loop_holder:
                    pending = asyncio.all_tasks(loop_holder["loop"])
                    for t in pending:
                        t.cancel()
                    try:
                        loop_holder["loop"].run_until_complete(
                            asyncio.gather(*pending, return_exceptions=True)
                        )
                    except Exception:
                        pass
                    loop_holder["loop"].close()
            except Exception:
                pass

    with _ACTIVE_LOCK:
        _active_comps[realm] = {
            "comp": comp,
            "loop": None,
            "thread": None,
            "subs": comp._subscriptions,
            "task": None,
            "cfg": {
                "url": url, "transport": transport,
                "serializers": [s.strip().lower() for s in serializers],
                "topics": sorted(set(topics))
            },
            "watchdog": None,
        }

    try:
        t = threading.Thread(target=_thread_main, daemon=True, name=f"Sub-{realm}")
        t.start()
    except Exception as e:
        # Error creando el hilo -> pinta en rojo y limpia
        with _ACTIVE_LOCK:
            _active_comps.pop(realm, None)
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        on_message_callback(realm, topics_label, ts, f"Thread create error: {e}", True, "system")
        return

    # Espera cortita a tener loop
    for _ in range(200):  # ~2s
        if "loop" in loop_holder:
            break
        time.sleep(0.01)

    with _ACTIVE_LOCK:
        entry = _active_comps.get(realm)
        if entry:
            entry["loop"] = loop_holder.get("loop")
            entry["thread"] = t

    # Watchdog: si en 3s no se llamó on_join, pintamos ROJO
    def _watchdog():
        with _ACTIVE_LOCK:
            entry2 = _active_comps.get(realm)
            comp2 = entry2["comp"] if entry2 else None
        if comp2 and not getattr(comp2, "_connected_flag", False):
            ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            on_message_callback(realm, topics_label, ts, "Connection timeout (no session established)", True, "system")

    timer = threading.Timer(3.0, _watchdog)
    timer.daemon = True
    timer.start()
    with _ACTIVE_LOCK:
        if realm in _active_comps:
            _active_comps[realm]["watchdog"] = timer

    logger.debug(f"Starting subscriber {realm}@{url} over {transport} for topics {topics}")


def ensure_subscriber(realm, url, transport, serializers, topics, on_message_callback):
    """Evita relanzar si la config no cambia; si cambia, para y vuelve a arrancar."""
    desired = {
        "url": (url or "").strip() if transport != "websocket" else (
            (url or "").strip() if (url or "").startswith("ws://") else f"ws://{(url or '').strip()}"
        ),
        "transport": (transport or "websocket").strip().lower(),
        "serializers": [s.strip().lower() for s in (serializers or ["json"])],
        "topics": sorted(set(topics or [])),
    }

    with _ACTIVE_LOCK:
        entry = _active_comps.get(realm)

    if entry and entry.get("cfg") == desired:
        # ya está con la misma config → no relanzar
        return "already-running"

    # si hay otro corriendo, para ese realm primero (no bloquea GUI)
    stop_all_subscribers(for_realm=realm)

    # espera breve para liberar sockets/hilo y no colisionar con start inmediato
    time.sleep(0.2)

    start_subscriber(url, realm, topics, on_message_callback, transport, serializers)
    return "started"


def stop_all_subscribers(callback=None, for_realm=None):
    """
    Para todos los subscribers en _active_comps sin bloquear la UI.
    Si se pasa callback(bool_ok), se invoca al terminar (desde hilo de GUI).
    """
    targets = list(_active_comps.items())
    if for_realm is not None:
        if for_realm in _active_comps:
            targets = [(for_realm, _active_comps[for_realm])]
        else:
            if callback:
                callback(True)
            return

    def _stop_entry(realm, entry):
        comp = entry.get("comp")
        loop = entry.get("loop")
        thread = entry.get("thread")
        subs = list(entry.get("subs") or [])
        task = entry.get("task")

        logger.info(f"[{realm}] stopping subscriber...")

        async def _graceful_shutdown():
            # 1) intenta desuscribir con timeout individual
            for sub in subs:
                try:
                    await asyncio.wait_for(sub.unsubscribe(), timeout=0.5)
                except Exception as e:
                    logger.debug(f"[{realm}] unsubscribe error: {e}")

            # 2) intenta cerrar el componente/sesión
            try:
                coro = comp.stop()
                if asyncio.iscoroutine(coro):
                    try:
                        await asyncio.wait_for(coro, timeout=0.8)
                    except Exception:
                        pass
            except Exception:
                pass

            # 3) cancela la task principal si sigue viva
            try:
                if task and not task.done():
                    task.cancel()
            except Exception:
                pass

            # 4) para el loop desde dentro sí o sí
            try:
                loop.stop()
            except Exception:
                pass

        ok = True
        if loop and loop.is_running():
            fut = asyncio.run_coroutine_threadsafe(_graceful_shutdown(), loop)
            try:
                fut.result(timeout=1.5)
            except Exception as e:
                logger.debug(f"[{realm}] shutdown coroutine timed out: {e}")
                ok = False

            try:
                loop.call_soon_threadsafe(loop.stop)
            except Exception:
                pass
        else:
            try:
                comp.stop()
            except Exception:
                pass

        if thread and thread.is_alive():
            thread.join(timeout=0.8)
            if thread.is_alive():
                logger.warning(f"[{realm}] thread still alive after stop request (detaching).")
                ok = False

        _active_comps.pop(realm, None)
        logger.info(f"[{realm}] stop finished (ok={ok}).")
        return ok

    def _bg():
        overall_ok = True
        for realm, entry in targets:
            try:
                ok = _stop_entry(realm, entry)
                overall_ok = overall_ok and ok
            except Exception:
                overall_ok = False
        if callback:
            try:
                callback(overall_ok)
            except Exception:
                pass

    t = threading.Thread(target=_bg, daemon=True, name="StopSubscribers")
    t.start()


# ================== UI (dialogs & viewer) ==================

class JsonDetailTabsDialog(QDialog):
    def __init__(self, data, parent=None):
        super().__init__(parent)
        try:
            if isinstance(data, str):
                data = json.loads(data)
        except Exception:
            pass
        self.setWindowTitle("JSON Details")
        self.resize(600, 400)
        layout = QVBoxLayout(self)
        btn_copy = QPushButton("Copy JSON", self)
        btn_copy.clicked.connect(lambda: self._copy_json(data))
        layout.addWidget(btn_copy)
        tabs = QTabWidget(self)
        raw = QTextEdit();
        raw.setReadOnly(True)
        try:
            raw.setPlainText(json.dumps(data, indent=2, ensure_ascii=False))
        except Exception:
            raw.setPlainText(str(data))
        tabs.addTab(raw, "Raw JSON")
        treew = QTreeWidget();
        treew.setHeaderHidden(True)
        self._build_tree(data, treew.invisibleRootItem())
        treew.expandAll()
        tabs.addTab(treew, "Tree View")
        layout.addWidget(tabs)

    def _copy_json(self, data):
        try:
            QApplication.clipboard().setText(json.dumps(data, indent=2, ensure_ascii=False))
        except Exception:
            QApplication.clipboard().setText(str(data))
        QMessageBox.information(self, "Copied", "JSON copied to clipboard.")

    def _build_tree(self, v, parent):
        if isinstance(v, dict):
            for k, vv in v.items():
                it = QTreeWidgetItem([str(k)])
                parent.addChild(it)
                self._build_tree(vv, it)
        elif isinstance(v, list):
            for i, vv in enumerate(v):
                it = QTreeWidgetItem([f"[{i}]"])
                parent.addChild(it)
                self._build_tree(vv, it)
        else:
            QTreeWidgetItem(parent, [str(v)])


class SubscriberMessageViewer(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.messages = []
        self.follow_tail = True

        layout = QVBoxLayout(self)

        ##AutoScroll control bar##
        ctrl = QWidget(self)
        hl = QHBoxLayout(ctrl)
        self.chk_follow = QCheckBox("Follow new messages", ctrl)
        self.chk_follow.setChecked(True)
        self.chk_follow.stateChanged.connect(self._toggle_follow)
        hl.addWidget(self.chk_follow)
        hl.addStretch(1)
        layout.addWidget(ctrl)



        self.table = QTableWidget(0, 4)  # Time, Realm, Topic, Source
        self.table.setHorizontalHeaderLabels(["Time", "Realm", "Topic", "Source"])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.table.itemDoubleClicked.connect(self._show_details)
        layout.addWidget(self.table)

    def add_message(self, realm, topic, ts, details, error=False, source="remote"):
        row = self.table.rowCount()
        self.table.insertRow(row)
        for col, txt in enumerate([ts, realm, topic, source]):
            it = QTableWidgetItem(str(txt))
            self.table.setItem(row, col, it)
        self.messages.append(details)

        if error:
            bg = QColor("#ffcccc")  # rojo suave
        elif source == "me":
            bg = QColor("#e0f7ff")  # cian suave
        elif source == "system":
            bg = QColor("#f0f0f0")  # gris claro
        else:
            bg = QColor("white")

        for col in range(self.table.columnCount()):
            self.table.item(row, col).setBackground(bg)

        if self.follow_tail:
            self.table.scrollToBottom()
            self.table.selectRow(row)

    def _toggle_follow(self, state):
        self.follow_tail = (state == Qt.Checked)

    def _show_details(self, it):
        dlg = JsonDetailTabsDialog(self.messages[it.row()], self)
        dlg.setAttribute(Qt.WA_DeleteOnClose, True)  # se destruye al cerrar
        dlg.setModal(False)  # no modal (modeless)
        dlg.show()  # permite abrir varias


# ================== TAB PRINCIPAL ==================

class SubscriberTab(QWidget):
    messageReceived = pyqtSignal(str, str, str, object, bool, str)  # + source

    def __init__(self, parent=None):
        super().__init__(parent)
        self.realms_topics = {}
        self.selected_topics = {}
        self.current_realm = None
        self.messageReceived.connect(self._on_message)
        self._build_ui()
        self._load_config()

    def _build_ui(self):
        from PyQt5.QtWidgets import QSplitter  # ← import local por si acaso
        main = QVBoxLayout(self)

        # ---- Panel izquierdo (config) ----
        leftPanel = QWidget(self)
        left = QVBoxLayout(leftPanel)

        self.chk_all_realms = QCheckBox("All Realms")
        self.chk_all_realms.stateChanged.connect(self._toggle_all_realms)
        left.addWidget(self.chk_all_realms)
        left.addWidget(QLabel("Realm | URL | Transport | Serializers"))

        self.realm_table = QTableWidget(0, 4)
        self.realm_table.setHorizontalHeaderLabels(["Realm", "URL", "Transport", "Serializers"])
        self.realm_table.itemDoubleClicked.connect(self._warn_realm_edit)
        self.realm_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.realm_table.cellClicked.connect(self._on_realm_clicked)
        left.addWidget(self.realm_table)

        hb = QHBoxLayout()
        self.new_realm = QLineEdit();
        self.new_realm.setPlaceholderText("New realm");
        hb.addWidget(self.new_realm)
        btn_add_realm = QPushButton("Add");
        btn_add_realm.clicked.connect(self._add_realm);
        hb.addWidget(btn_add_realm)
        btn_remove_realm = QPushButton("Remove");
        btn_remove_realm.clicked.connect(self._remove_realm);
        hb.addWidget(btn_remove_realm)
        left.addLayout(hb)

        self.chk_all_topics = QCheckBox("All Topics")
        self.chk_all_topics.stateChanged.connect(self._toggle_all_topics)
        left.addWidget(self.chk_all_topics)
        left.addWidget(QLabel("Topics"))
        self.topic_table = QTableWidget(0, 1)
        self.topic_table.setHorizontalHeaderLabels(["Topic"])
        self.topic_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.topic_table.itemChanged.connect(self._on_topic_toggled)
        left.addWidget(self.topic_table)

        hb2 = QHBoxLayout()
        self.new_topic = QLineEdit();
        self.new_topic.setPlaceholderText("New topic");
        hb2.addWidget(self.new_topic)
        btn_add_topic = QPushButton("Add");
        btn_add_topic.clicked.connect(self._add_topic);
        hb2.addWidget(btn_add_topic)
        btn_remove_topic = QPushButton("Remove");
        btn_remove_topic.clicked.connect(self._remove_topic);
        hb2.addWidget(btn_remove_topic)
        left.addLayout(hb2)

        ctrl = QHBoxLayout()
        self.btn_sub = QPushButton("Subscribe");
        self.btn_sub.clicked.connect(self._confirm_start);
        ctrl.addWidget(self.btn_sub)
        self.btn_stop = QPushButton("Stop");
        self.btn_stop.clicked.connect(self._stop_all);
        ctrl.addWidget(self.btn_stop)
        btn_reset = QPushButton("Reset Log");
        btn_reset.clicked.connect(self._reset_log);
        ctrl.addWidget(btn_reset)
        btn_export = QPushButton("Export to Excel…");
        btn_export.clicked.connect(self._export_excel_clicked);
        ctrl.addWidget(btn_export)
        left.addLayout(ctrl)

        # ---- Panel derecho (viewer) ----
        self.viewer = SubscriberMessageViewer(self)

        # ---- Splitter central ----
        splitter = QSplitter(Qt.Horizontal, self)
        splitter.addWidget(leftPanel)
        splitter.addWidget(self.viewer)
        splitter.setStretchFactor(0, 0)  # panel izq más estrecho
        splitter.setStretchFactor(1, 1)  # viewer se expande
        splitter.setSizes([350, 650])  # posición inicial del separador

        main.addWidget(splitter)
        self.setLayout(main)

    # def _config_path(self):
    #     base = os.path.dirname(os.path.dirname(__file__)) \
    #         if not getattr(sys, "frozen", False) else os.path.dirname(sys.executable)
    #     return os.path.join(base, "config", "realm_topic_config.json")

    def _config_path(self):
        return ensure_external_config(
            rel_output="config/realm_topic_config.json",
            rel_embedded_default="config/realm_topic_config.default.json"
    )

    # def _load_config(self):
    #     """Config por defecto (no lee fichero)."""
    #     self.realms_topics.clear()
    #     self.realms_topics["default_realm"] = {
    #         "router_url": "127.0.0.1:1234",
    #         "transport": "websocket",
    #         "serializers": ["json"],
    #         "topics": ["default_topic"]
    #     }
    #     self.selected_topics = {"default_realm": set(["default_topic"])}
    #     self._populate_realms()
    #
    def _load_config(self):
        p = self._config_path()
        if os.path.exists(p):
            with open(p,"r",encoding="utf-8") as f:
                data = json.load(f)
            self.realms_topics.clear()
            for it in data.get("realms",[]):
                r = it.get("realm"); url = it.get("router_url","")
                tr=it.get("transport","websocket")
                ss=it.get("serializers",["json"])
                ts=it.get("topics",[])
                if not r:
                    continue
                self.realms_topics[r] = {
                    "router_url": url,
                    "transport": tr,
                    "serializers": ss,
                    "topics": ts
                }
            self.selected_topics = {r:set(ts) for r, ts in ((k, v.get("topics", [])) for k, v in self.realms_topics.items())}
            self._populate_realms()
        else:
            QMessageBox.warning(self,"Warning",f"{p} not found")

    def _warn_realm_edit(self, item):
        QMessageBox.information(
            self,
            "Realm editing",
            "To change the realm name, please delete it first and add a new one."
        )

    def _populate_realms(self):
        self.realm_table.blockSignals(True)
        self.realm_table.setRowCount(0)
        for realm, info in self.realms_topics.items():
            r = self.realm_table.rowCount()
            self.realm_table.insertRow(r)
            it = QTableWidgetItem(realm)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if self.current_realm == realm else Qt.Unchecked)
            self.realm_table.setItem(r, 0, it)
            self.realm_table.setItem(r, 1, QTableWidgetItem(info["router_url"]))
            self.realm_table.setItem(r, 2, QTableWidgetItem(info["transport"]))
            self.realm_table.setItem(r, 3, QTableWidgetItem(",".join(info["serializers"])))
        self.realm_table.blockSignals(False)
        if self.realm_table.rowCount() > 0:
            self.realm_table.selectRow(0)
            self._on_realm_clicked(0, 0)
        else:
            self.current_realm = None
            self.topic_table.setRowCount(0)

    def _on_realm_clicked(self, row, col):
        it = self.realm_table.item(row, 0)
        if not it:
            return
        realm = it.text()
        self.current_realm = realm
        tops = self.realms_topics[realm]["topics"]
        sel = self.selected_topics.get(realm, set())
        self.topic_table.blockSignals(True)
        self.topic_table.setRowCount(0)
        for t in tops:
            i = self.topic_table.rowCount()
            self.topic_table.insertRow(i)
            ti = QTableWidgetItem(t)
            ti.setFlags(ti.flags() | Qt.ItemIsUserCheckable)
            ti.setCheckState(Qt.Checked if t in sel else Qt.Unchecked)
            self.topic_table.setItem(i, 0, ti)
        self.topic_table.blockSignals(False)

    def _add_realm(self):
        r = self.new_realm.text().strip()
        if not r or r in self.realms_topics:
            return
        url, ok1 = QInputDialog.getText(self, "URL", f"Add the url for the realm: {r}")
        transport, ok2 = QInputDialog.getText(self, "Transport", f"Add the transport for the realm: {r}")
        if not ok1 or not ok2:
            return
        self.realms_topics[r] = {
            "router_url": url, "transport": transport,
            "serializers": ["json"], "topics": []
        }
        self.selected_topics[r] = set()
        self.new_realm.clear()
        self._populate_realms()

    def _remove_realm(self):
        if self.current_realm and self.current_realm in self.realms_topics:
            del self.realms_topics[self.current_realm]
            self.selected_topics.pop(self.current_realm, None)
            self.current_realm = None
            self._populate_realms()

    def _add_topic(self):
        if not self.current_realm:
            return
        t = self.new_topic.text().strip()
        if not t:
            return
        info = self.realms_topics[self.current_realm]
        if t not in info["topics"]:
            info["topics"].append(t)
        self.selected_topics[self.current_realm].add(t)
        self.new_topic.clear()
        self._on_realm_clicked(self.realm_table.currentRow(), 0)

    def _remove_topic(self):
        if not self.current_realm:
            return
        sel = self.topic_table.currentRow()
        if sel < 0:
            return
        t = self.topic_table.item(sel, 0).text()
        if t in self.realms_topics[self.current_realm]["topics"]:
            self.realms_topics[self.current_realm]["topics"].remove(t)
        self.selected_topics[self.current_realm].discard(t)
        self._on_realm_clicked(self.realm_table.currentRow(), 0)

    def _on_topic_toggled(self, item):
        if item.column() != 0 or self.current_realm is None:
            return
        topic = item.text()
        sel = self.selected_topics.setdefault(self.current_realm, set())
        if item.checkState() == Qt.Checked:
            sel.add(topic)
        else:
            sel.discard(topic)

    def _toggle_all_realms(self, state):
        for row in range(self.realm_table.rowCount()):
            it = self.realm_table.item(row, 0)
            it.setCheckState(Qt.Checked if state == Qt.Checked else Qt.Unchecked)

    def _toggle_all_topics(self, state):
        if not self.current_realm:
            return
        for row in range(self.topic_table.rowCount()):
            it = self.topic_table.item(row, 0)
            it.setCheckState(Qt.Checked if state == Qt.Checked else Qt.Unchecked)
        if state == Qt.Checked:
            self.selected_topics[self.current_realm] = set(self.realms_topics[self.current_realm]["topics"])
        else:
            self.selected_topics[self.current_realm].clear()

    def _confirm_start(self):
        # No bloqueamos UI: paramos lo que hubiera y arrancamos nuevo por cada realm marcado
        stop_all_subscribers()  # limpio primero
        for row in range(self.realm_table.rowCount()):
            it = self.realm_table.item(row, 0)
            if not it or it.checkState() != Qt.Checked:
                continue

            realm = it.text()
            info = self.realms_topics[realm]
            url = info["router_url"].strip()
            tr = info["transport"].strip().lower()
            ss = [s.strip() for s in info["serializers"] if s.strip()]
            tops = list(self.selected_topics.get(realm, []))

            if not url or not tops:
                QMessageBox.warning(self, "Warning", f"Realm '{realm}' needs a URL and at least one topic.")
                continue

            ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.viewer.add_message(realm, ",".join(tops), ts, "Connecting...", False, "system")

            # Arranca (o reusa si misma config) usando ensure_subscriber
            status = ensure_subscriber(realm, url, tr, ss, tops, self._handle_message)
            if status == "already-running":
                ts2 = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self.viewer.add_message(realm, ",".join(tops), ts2, "Already subscribed (no changes).", False, "system")

    def _on_stop_done(self, ok: bool):
       pass

    # def _stop_all(self):
    #     # Guardamos el progress en un atributo para no perder la referencia
    #     self._progress = QProgressDialog("Stopping subscribers...", None, 0, 0, self)
    #     self._progress.setWindowTitle("Please wait")
    #     self._progress.setCancelButton(None)
    #     self._progress.setWindowModality(Qt.WindowModal)
    #     self._progress.setMinimumDuration(0)
    #     self._progress.show()
    #     QApplication.processEvents()
    #
    #     # Fail-safe: si en 5s no cierra, cerramos y avisamos
    #     self._stop_fail_safe = QTimer(self)
    #     self._stop_fail_safe.setSingleShot(True)
    #     self._stop_fail_safe.timeout.connect(self._on_stop_timeout_fail_safe)
    #     self._stop_fail_safe.start(5000)
    #
    #     # Lanzamos el stop en background con callback
    #     stop_all_subscribers(callback=self._on_stop_done)

    def _stop_all(self):
        def _after(ok: bool):
          ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
          def ui():
              msg = "All subscriptions stopped." if ok else "Stopped with warnings"
              self.viewer.add_message("", "", ts, msg, False, "system")
              QTimer.singleShot(0, ui)

        stop_all_subscribers(callback=_after)
        QMessageBox.information(self, "Subscriber", "All subscriptions stopped")

    def _on_stop_timeout_fail_safe(self):
        # Cierre forzado si algo se quedó colgado
        if getattr(self, "_progress", None):
            try:
                self._progress.close()
            except Exception:
                pass
            self._progress = None
        QMessageBox.warning(self, "Subscriber", "Stop took too long. Forced close of the progress dialog.")

    def _handle_message(self, realm, topic, ts, details, error=False, source="remote"):
        # No filtramos topic vacío: también queremos ver fallos generales (fila roja)
        self.messageReceived.emit(realm, topic, ts, details, error, source)
        try:
            log_to_file(ts, realm=realm, topic=topic,
                        router_url=self.realms_topics.get(realm, {}).get("router_url", ""),
                        payload=details)
        except Exception:
            pass

    @pyqtSlot(str, str, str, object, bool, str)
    def _on_message(self, realm, topic, ts, details, error, source):
        self.viewer.add_message(realm, topic, ts, details, error, source)

    def _reset_log(self):
        self.viewer.table.setRowCount(0)
        self.viewer.messages.clear()

    # ====== EXPORT A EXCEL ======
    def _export_excel_clicked(self):
        base_dir = ensure_project_subdir("exports")
        default_name = datetime.datetime.now().strftime("subscriber_logs_%Y%m%d_%H%M%S.xlsx")
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Export Subscriber Logs to Excel",
            os.path.join(base_dir, default_name),
            "Excel Files (*.xlsx)"
        )
        if not filepath:
            return
        try:
            self.export_logs_to_excel(filepath)
            QMessageBox.information(self, "Export", f"Excel exported:\n{filepath}")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Could not export:\n{e}")

    def export_logs_to_excel(self, filepath):
        from common.excel_exporter import export_subscriber_table_to_excel
        export_subscriber_table_to_excel(self.viewer.table, self.viewer.messages, filepath)

    # ==== Save/Load proyecto (igual que tenías) ====
    def saveProject(self):
        d = ensure_project_subdir("projects/subscriber")
        fp, _ = QFileDialog.getSaveFileName(self, "Save Subscriber Config", d, "JSON Files (*.json)")
        if not fp: return
        try:
            with open(fp, "w", encoding="utf-8") as f:
                json.dump(self.getProjectConfig(), f, indent=2, ensure_ascii=False)
            QMessageBox.information(self, "Subscriber", "Configuration saved.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not save:\n{e}")

    def loadProject(self):
        d = ensure_project_subdir("projects/subscriber")
        fp, _ = QFileDialog.getOpenFileName(self, "Load Subscriber Config", d, "JSON Files (*.json)")
        if not fp: return
        try:
            with open(fp, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            self.loadProjectFromConfig(cfg)
            QMessageBox.information(self, "Subscriber", "Configuration loaded.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not load:\n{e}")

    def getProjectConfig(self):
        realms = []
        for realm, info in self.realms_topics.items():
            realms.append({
                "realm": realm,
                "router_url": info["router_url"],
                "transport": info["transport"],
                "serializers": info["serializers"],
                "topics": info["topics"]
            })
        return {"realms": realms}

    def loadProjectFromConfig(self, config):
        self.realms_topics.clear()
        self.selected_topics.clear()
        realms = config.get("realms", [])
        for it in realms:
            realm = it.get("realm")
            url = it.get("router_url", "")
            transport = it.get("transport", "websocket")
            serializers = it.get("serializers", ["json"])
            topics = it.get("topics", [])
            if not realm:
                continue
            self.realms_topics[realm] = {
                "router_url": url,
                "transport": transport,
                "serializers": serializers,
                "topics": topics
            }
            self.selected_topics[realm] = set(topics)
        self._populate_realms()