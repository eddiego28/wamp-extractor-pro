import os
import json
import datetime
import asyncio
import threading
import logging
import re

from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QGroupBox, QFormLayout, QLineEdit, QMessageBox, QFileDialog,
    QComboBox, QCheckBox, QDialog, QTabWidget, QTextEdit,
    QTreeWidget, QTreeWidgetItem, QSplitter, QSizePolicy
)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor

from autobahn.asyncio.component import Component, run
from common.recorder import log_to_file
from publisher.pubEditor import PublisherEditorWidget

from common.paths import ensure_external_config, ensure_project_subdir


# ========== Configuración de Logging ==========
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
if not logger.handlers:
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter("%(asctime)s %(levelname)s: %(message)s"))
    logger.addHandler(ch)


# ========== Carga de Configuración Realms/Topics ==========
REALMS_CONFIG = {}


def load_realm_topic_config():
    """
    Carga config del publisher desde un JSON EXTERNO (escribible) junto al exe/proyecto.
    Si no existe, se copia desde el default embebido (--add-data).
    """
    global REALMS_CONFIG
    cfg_path = ensure_external_config(
        rel_output="config/realm_topic_config_pub.json",
        rel_embedded_default="config/realm_topic_config_pub.default.json"
    )
    try:
        with open(cfg_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        REALMS_CONFIG = {
            it["realm"]: {
                "router_url": it.get("router_url", ""),
                "transport": it.get("transport", "websocket"),
                "serializers": it.get("serializers", ["json"]),
                "topics": it.get("topics", [])
            }
            for it in data.get("realms", [])
            if it.get("realm")
        }
    except Exception as e:
        logger.error(f"Error loading pub config: {e}")
        REALMS_CONFIG = {
            "default": {
                "router_url": "127.0.0.1:60008",
                "transport": "websocket",
                "serializers": ["json"],
                "topics": []
            }
        }

# def load_realm_topic_config():
#     global REALMS_CONFIG
#     REALMS_CONFIG = {
#         "default_realm": {
#             "router_url": "127.0.0.1:1234",
#             "transport": "websocket",
#             "serializers": ["json"],
#             "topics": ["default_topic"]
#         }
#     }

load_realm_topic_config()

# ========== Componentes Publisher activos ==========
_active_pub_comps = {}

def make_pub_component(realm, url, transport, serializers, topic, widget):
    """
    Crea un Component WAMP para Publisher.
    Soporta WebSocket y RawSocket (json/msgpack).
    """
    if transport == "rawsocket":
        m = re.match(r"^([^:/\s]+):(\d+)$", url)
        if not m:
            raise ValueError(f"RawSocket URL inválida: {url}")
        host, port = m.group(1), int(m.group(2))
        if not serializers:
            serializers = ["json"]
        if len(serializers) > 1:
            QMessageBox.warning(widget, "Warning",
                                "RawSocket only supports one serializer. Using first: %s" % serializers[0])
        serializer = serializers[0].lower()
        if serializer not in ("json", "msgpack"):
            QMessageBox.critical(widget, "Error", "RawSocket only supports msgpack or json'.")
            raise ValueError("Serializador no soportado para RawSocket.")
        tx = {
            "type": "rawsocket",
            "endpoint": {"type": "tcp", "host": host, "port": port},
            "serializer": serializer
        }
    else:
        full = url if url.startswith("ws://") else f"ws://{url}"
        valid_serializers = [s.lower() for s in serializers if s.lower() in ("json", "msgpack")]
        if not valid_serializers:
            QMessageBox.critical(widget, "Error", "only supports msgpack or json.")
            raise ValueError("Serializer not supported with WebSocket.")
        tx = {
            "type": "websocket",
            "url": full,
            "serializers": valid_serializers
        }
    comp = Component(transports=[tx], realm=realm)

    @comp.on_join
    async def joined(session, details):
        loop = asyncio.get_event_loop()
        widget.session = session
        widget.loop = loop
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        parent = widget
        while parent and not hasattr(parent, "addPublisherLog"):
            parent = parent.parent()
        logger.info(f"[Pub:{realm}|{topic}] joined")
        await asyncio.Future()  # Mantener sesión

    @comp.on_leave
    def left(session, details):
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        parent = widget
        while parent and not hasattr(parent, "addPublisherLog"):
            parent = parent.parent()
        if parent:
            parent.addPublisherLog(realm, topic, ts, f"Left: {details}", error=False)
        logger.info(f"[Pub:{realm}|{topic}] left: {details}")

    return comp


def start_publisher(url, realm, topic, widget, transport="websocket", serializers=None):
    serializers = serializers or ["json"]
    if transport == "rawsocket":
        if not re.match(r"^[^:/\s]+:\d+$", url):
            QMessageBox.critical(None, "URL inválida", "RawSocket: must be host:port")
            return
    else:
        if not re.match(r"^(ws://)?[^:/\s]+:\d+$", url):
            QMessageBox.critical(None, "URL inválida", "WebSocket: must be host:port")
            return
    comp = make_pub_component(realm, url, transport, serializers, topic, widget)
    _active_pub_comps[(realm, topic)] = comp

    def _run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        run([comp], start_loop=False)
        try:
            loop.run_forever()
        finally:
            loop.close()

    t = threading.Thread(target=_run, daemon=True, name=f"Pub-{realm}-{topic}")
    t.start()
    logger.debug(f"Starting publisher {realm}@{url} ({transport}) ➤ topic={topic}")


def stop_all_publishers():
    for key, comp in list(_active_pub_comps.items()):
        realm, topic = key
        logger.info(f"Stopping publisher for {realm}|{topic}")
        comp.stop()
    _active_pub_comps.clear()


def send_message_now(session, loop, topic, message, delay=0):
    if session is None or loop is None:
        return

    async def _send():
        if delay > 0:
            await asyncio.sleep(delay)
        try:
            if isinstance(message, dict):
                msg = dict(message)
                msg["__src"] = "me"
                session.publish(topic, **msg)
            else:
                session.publish(topic, message)
            ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            #log_to_file(ts, realm=session.config.realm, topic=topic, router_url="", payload=message)
        except Exception as exc:
            logger.error(f"Failed to send message: {exc}")

    asyncio.run_coroutine_threadsafe(_send(), loop)


# ========== MessageConfigWidget ==========
class MessageConfigWidget(QWidget):
    def __init__(self, msg_id, parent=None):
        super().__init__(parent)
        self.msg_id = msg_id
        self.session = None
        self.loop = None
        self._build_ui()

    def _build_ui(self):
        self.setStyleSheet("font:10pt 'Segoe UI'")
        layout = QVBoxLayout(self)

        # ----- Header -----
        header = QWidget()
        hl = QHBoxLayout(header)
        self.enableCheck = QCheckBox()
        self.enableCheck.setChecked(True)
        self.enableCheck.stateChanged.connect(self._on_enable_changed)
        hl.addWidget(self.enableCheck)
        self.headerLabel = QLabel(f"Message #{self.msg_id}")
        hl.addWidget(self.headerLabel)
        hl.addStretch()
        self.minimizeButton = QPushButton("–")
        self.minimizeButton.setFixedSize(20, 20)
        self.minimizeButton.clicked.connect(self.toggleMinimize)
        hl.addWidget(self.minimizeButton)
        self.deleteButton = QPushButton("Delete")
        self.deleteButton.setFixedSize(60, 20)
        self.deleteButton.clicked.connect(self.deleteSelf)
        hl.addWidget(self.deleteButton)
        layout.addWidget(header)

        # ----- Content Widget -----
        self.contentWidget = QWidget()
        contentL = QVBoxLayout(self.contentWidget)

        # --- Connection settings group ---
        connG = QGroupBox("Connection Settings")
        connF = QFormLayout(connG)

        # Realm with add/remove
        realmBox = QHBoxLayout()
        self.realmCombo = QComboBox()
        self.realmCombo.addItems(REALMS_CONFIG.keys())
        self.realmCombo.currentTextChanged.connect(self._update_topics)
        realmBox.addWidget(self.realmCombo)
        self.realmEdit = QLineEdit()
        self.realmEdit.setPlaceholderText("New realm")
        realmBox.addWidget(self.realmEdit)
        btnAddRealm = QPushButton("Add")
        btnAddRealm.clicked.connect(self._add_realm)
        realmBox.addWidget(btnAddRealm)
        btnDelRealm = QPushButton("Remove")
        btnDelRealm.clicked.connect(self._remove_realm)
        realmBox.addWidget(btnDelRealm)
        connF.addRow("Realm:", realmBox)

        # Router URL
        self.urlEdit = QLineEdit()
        connF.addRow("Router URL:", self.urlEdit)

        # Transport
        self.transportCombo = QComboBox()
        self.transportCombo.addItems(["websocket", "rawsocket"])
        self.transportCombo.currentTextChanged.connect(self._on_transport_changed)
        connF.addRow("Transport:", self.transportCombo)

        # Serializers
        self.serializersEdit = QLineEdit("json")
        self.serializersEdit.setToolTip("Ejemplo: json,msgpack")
        connF.addRow("Serializers:", self.serializersEdit)

        # Topic with add/remove
        topicBox = QHBoxLayout()
        self.topicCombo = QComboBox()
        topicBox.addWidget(self.topicCombo)
        self.topicEdit = QLineEdit()
        self.topicEdit.setPlaceholderText("New topic")
        topicBox.addWidget(self.topicEdit)
        btnAddTopic = QPushButton("Add")
        btnAddTopic.clicked.connect(self._add_topic)
        topicBox.addWidget(btnAddTopic)
        btnDelTopic = QPushButton("Remove")
        btnDelTopic.clicked.connect(self._remove_topic)
        topicBox.addWidget(btnDelTopic)
        connF.addRow("Topic:", topicBox)

        contentL.addWidget(connG)

        # --- Message Content Editor group ---
        contentG = QGroupBox("Message Content")
        egl = QVBoxLayout(contentG)
        self.editorWidget = PublisherEditorWidget(parent=self)
        egl.addWidget(self.editorWidget)
        contentL.addWidget(contentG)

        # Botón Send Now integrado con validación UX
        btnSend = QPushButton("Send Now")
        btnSend.clicked.connect(self._on_send_now_safely)
        self.editorWidget.setSendNowButton(btnSend)
        contentL.addWidget(btnSend)

        layout.addWidget(self.contentWidget)
        self._update_topics(self.realmCombo.currentText())
        self.setLayout(layout)

        self.detachButton = QPushButton("Detach")
        self.detachButton.setFixedSize(60, 20)
        self.detachButton.clicked.connect(self.detachEditor)
        hl.addWidget(self.detachButton)

    def _on_enable_changed(self, state):
        self.contentWidget.setDisabled(state != Qt.Checked)

    def detachEditor(self):
        # Si ya hay una ventana flotante abierta, no la vuelvas a abrir
        if hasattr(self, "_detached_win") and self._detached_win and self._detached_win.isVisible():
            self._detached_win.raise_()
            self._detached_win.activateWindow()
            return
        # Crea una nueva ventana para el editor (QDialog o QWidget)
        from PyQt5.QtWidgets import QDialog, QVBoxLayout
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Detached Message Editor #{self.msg_id}")
        dlg.setMinimumSize(600, 500)
        lay = QVBoxLayout(dlg)
        # Saca el editorWidget del widget original y lo mete en la ventana flotante
        self.editorWidget.setParent(dlg)
        lay.addWidget(self.editorWidget)
        dlg.finished.connect(lambda _: self._reattachEditor())
        dlg.show()
        self._detached_win = dlg

    def _reattachEditor(self):
        # Cuando cierran la ventana, vuelve a poner el editor en el sitio original
        self.editorWidget.setParent(self.contentWidget)
        layout = self.contentWidget.layout()
        layout.addWidget(self.editorWidget)

    def _update_topics(self, realm):
        info = REALMS_CONFIG.get(realm, {})
        self.urlEdit.setText(info.get("router_url", ""))
        self.transportCombo.setCurrentText(info.get("transport", "websocket"))
        self.serializersEdit.setText(",".join(info.get("serializers", ["json"])))
        self.topicCombo.clear()
        self.topicCombo.addItems(info.get("topics", []))

    def _on_transport_changed(self, transport):
        # UX: Si es rawsocket, solo permitir un serializador
        if transport == "rawsocket":
            current = self.serializersEdit.text()
            if "," in current:
                first = current.split(",")[0]
                self.serializersEdit.setText(first)
                QMessageBox.information(self, "Info", "RawSocket only admits one serializer.")

    def _add_realm(self):
        r = self.realmEdit.text().strip()
        if not r:
            return
        if r in REALMS_CONFIG:
            QMessageBox.warning(self, "Warning", f"Realm '{r}' already exists.")
            return
        REALMS_CONFIG[r] = {
            "router_url": "",
            "transport": "websocket",
            "serializers": ["json"],
            "topics": []
        }
        self.realmCombo.addItem(r)
        self.realmEdit.clear()

    def _remove_realm(self):
        r = self.realmCombo.currentText()
        if r in REALMS_CONFIG:
            del REALMS_CONFIG[r]
            self.realmCombo.clear()
            self.realmCombo.addItems(REALMS_CONFIG.keys())
            self._update_topics(self.realmCombo.currentText())

    def _add_topic(self):
        realm = self.realmCombo.currentText()
        t = self.topicEdit.text().strip()
        if not t:
            return
        if t in REALMS_CONFIG[realm]["topics"]:
            QMessageBox.warning(self, "Warning", f"Topic '{t}' already exists in realm '{realm}'.")
            return
        REALMS_CONFIG[realm]["topics"].append(t)
        self.topicCombo.addItem(t)
        self.topicEdit.clear()

    def _remove_topic(self):
        realm = self.realmCombo.currentText()
        t = self.topicCombo.currentText()
        if t in REALMS_CONFIG[realm]["topics"]:
            REALMS_CONFIG[realm]["topics"].remove(t)
            self._update_topics(realm)

    def _on_send_now_safely(self):
        try:
            cfg = self.getConfig()
        except Exception as e:
            self.editorWidget.highlight_json_error()
            QMessageBox.critical(self, "Error", f"Invalid JSON for Msg#{self.msg_id}:\n\n{str(e)}")
            return
        if not self.session or not self.loop:
            QMessageBox.warning(
                self,
                "Error",
                f"No active session for Msg#{self.msg_id}. Pulsa Start Publisher first."
            )
            return
        topic = self.topicCombo.currentText().strip()
        send_message_now(self.session, self.loop, topic, cfg["content"], delay=0)
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        parent = self
        while parent and not hasattr(parent, "addPublisherLog"):
            parent = parent.parent()
        if parent:
            parent.addPublisherLog(self.realmCombo.currentText(), topic, ts, json.dumps(cfg["content"], indent=2))

    def toggleMinimize(self):
        self.contentWidget.setVisible(not self.contentWidget.isVisible())
        self.minimizeButton.setText("+" if not self.contentWidget.isVisible() else "–")

    def deleteSelf(self):
        parent = self.parentWidget()
        while parent and not hasattr(parent, "removeMessageWidget"):
            parent = parent.parentWidget()
        if parent:
            parent.removeMessageWidget(self)

    def getConfig(self):
        is_valid, error_msg = self.editorWidget.validate_json_and_format()
        if not is_valid:
            self.editorWidget.highlight_json_error()
            raise ValueError(error_msg)
        content = json.loads(self.editorWidget.jsonPreview.toPlainText())
        # Serializers puede venir separado por comas
        # serializers = [s.strip() for s in self.serializersEdit.text().split(",") if s.strip()]
        # if self.transportCombo.currentText() == "rawsocket" and len(serializers) > 1:
        #     serializers = [serializers[0]]
        serializers =["json"]
        return {
            "realm": self.realmCombo.currentText(),
            "router_url": self.urlEdit.text().strip(),
            "topic": self.topicCombo.currentText().strip(),
            "content": json.loads(self.editorWidget.jsonPreview.toPlainText()),
            "transport": REALMS_CONFIG.get(self.realmCombo.currentText(), {}).get("transport", "websocket"),
            "serializers": serializers, #REALMS_CONFIG.get(self.realmCombo.currentText(), {}).get("serializers", ["json"]),
            "mode": self.editorWidget.get_mode(),
            "time": self.editorWidget.get_time()
        }


# ========== PublisherTab principal (gestión de mensajes/logs/envío) ==========
class PublisherTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.msgWidgets = []
        self.next_id = 1
        self._build_ui()

    def _build_ui(self):
        splitter = QSplitter(Qt.Horizontal)
        left = QWidget();
        ll = QVBoxLayout(left)
        row = QHBoxLayout()
        self.btn_start = QPushButton("Start Publisher");
        row.addWidget(self.btn_start)
        self.btn_stop = QPushButton("Stop Publisher");
        row.addWidget(self.btn_stop)
        self.btn_reset = QPushButton("Reset Log");
        row.addWidget(self.btn_reset)
        ll.addLayout(row)
        self.viewer = PublisherMessageViewer(self);
        ll.addWidget(self.viewer)
        splitter.addWidget(left)
        right = QWidget();
        rl = QVBoxLayout(right)
        self.btn_add = QPushButton("Add Message");
        rl.addWidget(self.btn_add)
        self.scroll = QScrollArea();
        self.scroll.setWidgetResizable(True)
        self.container = QWidget();
        self.vlay = QVBoxLayout(self.container)
        self.scroll.setWidget(self.container);
        rl.addWidget(self.scroll)
        bottom = QHBoxLayout()
        self.btn_scenario = QPushButton("Start Scenario");
        bottom.addWidget(self.btn_scenario)
        self.btn_instant = QPushButton("Send Instant Message");
        bottom.addWidget(self.btn_instant)
        rl.addLayout(bottom)
        splitter.addWidget(right)
        layout = QVBoxLayout(self);
        layout.addWidget(splitter)
        splitter.setSizes([300, 700])

        self.btn_add.clicked.connect(self._add_message)
        self.btn_start.clicked.connect(self._start_publishers)
        self.btn_stop.clicked.connect(self._stop_all_publishers)
        self.btn_reset.clicked.connect(self._reset_log)
        self.btn_instant.clicked.connect(self._send_all_instant)
        self.btn_scenario.clicked.connect(self._start_scenario)

    def _add_message(self):
        w = MessageConfigWidget(self.next_id, parent=self)
        self.vlay.addWidget(w)
        self.msgWidgets.append(w)
        self.next_id += 1

    def removeMessageWidget(self, widget):
        if widget in self.msgWidgets:
            idx = self.msgWidgets.index(widget)
            self.msgWidgets.pop(idx)
            self.vlay.removeWidget(widget)
            widget.deleteLater()
            for i, w in enumerate(self.msgWidgets, start=1):
                w.msg_id = i
                w.headerLabel.setText(f"Message #{i}")
            self.next_id = len(self.msgWidgets) + 1

    def addPublisherLog(self, realm: str, topic: str, ts: str, details: any, error: bool = False):
        # Evitar logs duplicados para "Publisher connected" y "Publisher started"
        if isinstance(details, str) and ("Publisher connected" in details or "Publisher started" in details):
            # Solo agrega si no hay ya un log igual en la tabla (puedes refinar el filtro si lo ves necesario)
            for i in range(self.viewer.table.rowCount()):
                if (self.viewer.table.item(i, 1) and self.viewer.table.item(i, 1).text() == realm and
                        self.viewer.table.item(i, 2) and self.viewer.table.item(i, 2).text() == topic and
                        self.viewer.table.item(i, 0) and self.viewer.table.item(i, 0).text() == ts and
                        (self.viewer.logs[i] == details)):
                    return  # Ya está este log
            # Solo muestra "Publisher started" si existen ambos
            if "Publisher connected" in details:
                return  # Ignora, solo muestra "started"
        self.viewer.add_message(realm, topic, ts, details, error)

    def _block_buttons(self, seconds=2):
        btns = [self.btn_start, self.btn_stop, self.btn_reset, self.btn_instant, self.btn_scenario]
        for btn in btns:
            btn.setDisabled(True)
        QTimer.singleShot(seconds * 1000, lambda: [btn.setDisabled(False) for btn in btns])

    def _try_get_config(self, widget):
        try:
            return widget.getConfig()
        except Exception as e:
            widget.editorWidget.highlight_json_error()
            self._block_buttons(2)
            QMessageBox.critical(self, "Error", f"Error en mensaje #{widget.msg_id}:\n\n{str(e)}")
            return None

    def _check_session_and_loop(self, widget):
        if not getattr(widget, "session", None) or not getattr(widget, "loop", None):
            self._block_buttons(2)
            QMessageBox.warning(self, "Error",
                                f"No active session for Msg#{widget.msg_id}. Click Start Publisher first."
                                )
            return False
        return True

    def _start_publishers(self):
        for w in self.msgWidgets:
            cfg = self._try_get_config(w)
            if cfg is None:
                return
            start_publisher(
                cfg["router_url"], cfg["realm"], cfg["topic"], w, cfg["transport"], ["json"] #cfg["serializers"]
            )
            QTimer.singleShot(500, lambda w=w, c=cfg: self._log_started(w, c))

    def _log_started(self, widget, cfg):
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if not getattr(widget, "session", None):
            self.addPublisherLog(cfg["realm"], cfg["topic"], ts, "Failed to connect", True)
        else:
            self.addPublisherLog(cfg["realm"], cfg["topic"], ts, "Publisher started")

    def _stop_all_publishers(self):
        stop_all_publishers()
        QMessageBox.information(self, "Publisher", "All publishers stopped")

    def _reset_log(self):
        self.viewer.table.setRowCount(0)
        self.viewer.logs.clear()

    def _send_all_instant(self):
        # Enviar todos los mensajes, cada uno a su topic seleccionado (no todos a todos)
        for w in self.msgWidgets:
            if not getattr(w, "session", None) or not getattr(w, "loop", None):
                QMessageBox.warning(self, "Warning", f"No session for Msg#{w.msg_id}")
                continue
            try:
                cfg = w.getConfig()
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))
                continue
            topic = cfg["topic"]
            send_message_now(w.session, w.loop, topic, cfg["content"], delay=0)
            ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.addPublisherLog(cfg["realm"], topic, ts, json.dumps(cfg["content"], indent=2))

    def _start_scenario(self):
        for w in self.msgWidgets:
            try:
                cfg = w.getConfig()
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))
                continue

            mode = cfg.get("mode", "On-Demand")
            tstr = cfg.get("time", "00:00:00")
            try:
                if mode == "On-Demand":
                    delay = 0
                elif mode == "Programmed":
                    h, m, s = map(int, tstr.split(":"))
                    delay = h * 3600 + m * 60 + s
                else:  # "System Time"
                    now = datetime.datetime.now()
                    h, m, s = map(int, tstr.split(":"))
                    tgt = now.replace(hour=h, minute=m, second=s, microsecond=0)
                    if tgt < now:
                        tgt += datetime.timedelta(days=1)
                    delay = (tgt - now).total_seconds()
            except Exception:
                QMessageBox.critical(self, "Error", f"Invalid time for Msg#{w.msg_id}")
                continue

            # ----------- IMPORTANTE: Cierra el scope aquí -----------
            def make_send(w, cfg):
                def do_send():
                    if not getattr(w, "session", None) or not getattr(w, "loop", None):
                        QMessageBox.warning(self, "Warning", f"No session for Msg#{w.msg_id}")
                        return
                    send_message_now(w.session, w.loop, cfg["topic"], cfg["content"], delay=0)
                    ts2 = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.addPublisherLog(cfg["realm"], cfg["topic"], ts2, json.dumps(cfg["content"], indent=2))

                return do_send

            # --------------------------------------------------------

            QTimer.singleShot(int(delay * 1000), make_send(w, cfg))

    def saveProject(self):
        d = ensure_project_subdir("projects/publisher")
        fp, _ = QFileDialog.getSaveFileName(self, "Save Publisher Config", d, "JSON Files (*.json)")
        if not fp:
            return
        try:
            with open(fp, "w", encoding="utf-8") as f:
                json.dump(self.getProjectConfig(), f, indent=2, ensure_ascii=False)
            QMessageBox.information(self, "Publisher", "Configuration saved.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not save:\n{e}")

    def loadProject(self):
        d = ensure_project_subdir("projects/publisher")
        fp, _ = QFileDialog.getOpenFileName(self, "Load Publisher Config", d, "JSON Files (*.json)")
        if not fp:
            return
        try:
            with open(fp, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            self.loadProjectFromConfig(cfg)
            QMessageBox.information(self, "Publisher", "Configuration loaded.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not load:\n{e}")

    def getProjectConfig(self):
        return {"messages": [w.getConfig() for w in self.msgWidgets]}

    def loadProjectFromConfig(self, config):
        # --- Limpiar anteriores ---
        for w in list(self.msgWidgets):
            w.deleteLater()
        self.msgWidgets.clear()
        self.next_id = 1

        # --- Reconstruir REALMS_CONFIG ---
        global REALMS_CONFIG
        REALMS_CONFIG.clear()
        for msg in config.get("messages", []):
            realm = msg.get("realm", "")
            url = msg.get("router_url", "")
            topic = msg.get("topic", "")
            transport = msg.get("transport", "websocket")
            serializers = msg.get("serializers", ["json"])
            if realm not in REALMS_CONFIG:
                REALMS_CONFIG[realm] = {
                    "router_url": url,
                    "transport": transport,
                    "serializers": serializers,
                    "topics": []
                }
            if topic and topic not in REALMS_CONFIG[realm]["topics"]:
                REALMS_CONFIG[realm]["topics"].append(topic)

        # --- Ahora sí, crear los widgets ---
        for msg in config.get("messages", []):
            w = MessageConfigWidget(self.next_id, parent=self)
            w.realmCombo.clear()
            w.realmCombo.addItems(REALMS_CONFIG.keys())
            w.realmCombo.setCurrentText(msg.get("realm", ""))
            w.urlEdit.setText(msg.get("router_url", ""))
            w.topicCombo.clear()
            w.topicCombo.addItems(REALMS_CONFIG[msg.get("realm", "")]["topics"])
            w.topicCombo.setCurrentText(msg.get("topic", ""))
            w.editorWidget.jsonPreview.setPlainText(json.dumps(msg.get("content", {}), indent=2, ensure_ascii=False))
            self.vlay.addWidget(w)
            self.msgWidgets.append(w)
            self.next_id += 1


# ========== Viewer de logs Publisher ==========
class PublisherMessageViewer(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.logs = []
        layout = QVBoxLayout(self)
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Time", "Realm", "Topic"])
        # Ajusta el tamaño de las columnas: más pequeño para Time
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.itemDoubleClicked.connect(self._show)
        layout.addWidget(self.table)

    def add_message(self, realm, topic, timestamp, details, error=False):
        r = self.table.rowCount()
        self.table.insertRow(r)
        for c, t in enumerate([timestamp, realm, topic]):
            it = QTableWidgetItem(t)
            self.table.setItem(r,c,it)
            self.logs.append(details)

        if error:
            bg = QColor("#ffcccc")
        else:
            bg = QColor("white")

        for c in range(self.table.columnCount()):
            item = self.table.item(r,c)
            if item:
                item.setBackground(bg)

    def _show(self, it):
        dlg = JsonDetailTabsDialog(self.logs[it.row()], self)
        dlg.setAttribute(Qt.WA_DeleteOnClose, True)  # se destruye al cerrar
        dlg.setModal(False)  # no modal (modeless)
        dlg.show()  # permite abrir varias


# ========== Dialogo JSON Details ==========
class JsonDetailTabsDialog(QDialog):
    def __init__(self, data, parent=None):
        super().__init__(parent)
        try:
            obj = json.loads(data) if isinstance(data, str) else data
        except:
            obj = data
        self.raw = json.dumps(obj, indent=2, ensure_ascii=False)
        self.setWindowTitle("JSON Details")
        self.resize(600, 400)
        layout = QVBoxLayout(self)
        btn = QPushButton("Copy JSON")
        btn.clicked.connect(self._copy)
        layout.addWidget(btn)
        tabs = QTabWidget();
        layout.addWidget(tabs)
        te = QTextEdit();
        te.setReadOnly(True);
        te.setPlainText(self.raw)
        tabs.addTab(te, "Raw JSON")
        tree = QTreeWidget();
        tree.setHeaderHidden(True)
        self._build(obj, tree.invisibleRootItem());
        tree.expandAll()
        tabs.addTab(tree, "Tree View")

    def _build(self, v, parent):
        if isinstance(v, dict):
            for k, vv in v.items():
                it = QTreeWidgetItem([str(k)]);
                parent.addChild(it)
                self._build(vv, it)
        elif isinstance(v, list):
            for i, vv in enumerate(v):
                it = QTreeWidgetItem([f"[{i}]"]);
                parent.addChild(it)
                self._build(vv, it)
        else:
            QTreeWidgetItem(parent, [str(v)])

    def _copy(self):
        QApplication.clipboard().setText(self.raw)
        QMessageBox.information(self, "Copied", "JSON copied to clipboard.")

# El ultimo
